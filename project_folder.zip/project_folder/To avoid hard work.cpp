#include <iostream>
#include <fstream> // 파일 출력을 위한 헤더
using namespace std;

int main() {
    // 출력 파일 생성
    ofstream file("output.txt");

    if (file.is_open()) {
        const double RA_OFFSET = 265.0833;
        const double DEC_OFFSET = 32.2167;
        int N = 484; // 최대 반복 횟수

        // 1부터 N까지 반복하여 텍스트 생성
        for (int i = 1; i <= N; ++i) {
            file << "double x" << i << " = (ra" << i << " - " << RA_OFFSET << ") * distance" << i << ";\n";
            file << "double y" << i << " = (dec" << i << " + " << DEC_OFFSET << ") * distance" << i << ";\n";
            file << "double z" << i << " = distance" << i << ";\n\n";
            file << "bodies.push_back(Body(Vector(x" << i << ", y" << i << ", z" << i 
                 << "), Vector(0, 0, 0), mass" << i << ", radius" << i << "));\n\n";
        }
        file.close(); // 파일 닫기
        cout << "File output.txt created successfully!" << endl;
    } else {
        cerr << "Error: Unable to open file!" << endl;
    }

    return 0;
}

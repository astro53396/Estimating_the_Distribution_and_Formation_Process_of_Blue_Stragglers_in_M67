#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

struct StarData {
    double ra;
    double dec;
    double distance;
    double pmra;
    double pmdec;
    int binary;
    double mv;
    double teff;
    double logg;
    double mbol;
    double mass;
    double radius;
};

int main() {
    std::ifstream file("C:/Users/gun53/Downloads/project_folder/output/M07.txt");

    if (!file) {
        std::cerr << "Failed to open input file!" << std::endl;
        return 1;
    }

    std::string line;
    std::vector<StarData> stars;

    while (std::getline(file, line)) {
        std::istringstream iss(line);
        StarData star;

        if (!(iss >> star.ra >> star.dec >> star.distance >> star.pmra >> star.pmdec
                  >> star.binary >> star.mv >> star.teff >> star.logg >> star.mbol >> star.mass >> star.radius)) {
            continue; // 데이터 파싱 실패 시 건너뛰기
        }

        if (star.distance > 0) {
            stars.push_back(star);
        }
    }

    std::ofstream outputFile("C:/Users/gun53/Downloads/project_folder/output/M07_res.txt");

    if (!outputFile) {
        std::cerr << "Failed to open output file!" << std::endl;
        return 1;
    }

    int count = 1; // 번호 초기화
    for (const auto& star : stars) {
        outputFile << "double ra" << count << " = " << star.ra
                   << ", dec" << count << " = " << star.dec
                   << ", mass" << count << " = " << star.mass
                   << ", radius" << count << " = " << star.radius
                   << ", distance" << count << " = " << star.distance
                   << ", pmra" << count << " = " << star.pmra
                   << ", pmdec" << count << " = " << star.pmdec << ";" << std::endl;
        ++count;
    }

    file.close();
    outputFile.close();

    std::cout << "Filtered data saved successfully!" << std::endl;

    return 0;
}

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>

struct Star {
    double ra;
    double dec;
    double G;
    double BP_RP;
    double Binary;
    double V;
    double BP_G;
    double distance;
    double teff;
    double logg;
    double Mv;
    double Mbol;
    double logM;
    double logR;
    double M;
    double R;
    double Pra;
    double Pdc;
    std::string spectralType;
    double BC;
};

std::string determineSpectralType(double teff) {
    if (teff >= 30000) {
        if (teff >= 45000) return "O2";
        if (teff >= 40000) return "O3";
        if (teff >= 37000) return "O4";
        if (teff >= 34000) return "O5";
        if (teff >= 32000) return "O6";
        if (teff >= 30000) return "O7";
    } else if (teff >= 10000) {
        if (teff >= 28000) return "B0";
        if (teff >= 25000) return "B1";
        if (teff >= 22000) return "B2";
        if (teff >= 20000) return "B3";
        if (teff >= 18000) return "B4";
        if (teff >= 16000) return "B5";
        if (teff >= 14000) return "B6";
        if (teff >= 12000) return "B7";
        if (teff >= 10000) return "B8";
    } else if (teff >= 7500) {
        if (teff >= 9500) return "A0";
        if (teff >= 9000) return "A1";
        if (teff >= 8500) return "A2";
        if (teff >= 8000) return "A3";
        if (teff >= 7750) return "A4";
        if (teff >= 7500) return "A5";
    } else if (teff >= 6000) {
        if (teff >= 7000) return "F0";
        if (teff >= 6750) return "F1";
        if (teff >= 6500) return "F2";
        if (teff >= 6250) return "F3";
        if (teff >= 6000) return "F4";
    } else if (teff >= 5200) {
        if (teff >= 5900) return "G0";
        if (teff >= 5700) return "G1";
        if (teff >= 5500) return "G2";
        if (teff >= 5300) return "G3";
        if (teff >= 5200) return "G4";
    } else if (teff >= 3700) {
        if (teff >= 5000) return "K0";
        if (teff >= 4800) return "K1";
        if (teff >= 4600) return "K2";
        if (teff >= 4400) return "K3";
        if (teff >= 4200) return "K4";
        if (teff >= 4000) return "K5";
        if (teff >= 3800) return "K6";
        if (teff >= 3700) return "K7";
    } else if (teff > 0) {
        if (teff >= 3600) return "M0";
        if (teff >= 3500) return "M1";
        if (teff >= 3400) return "M2";
        if (teff >= 3300) return "M3";
        if (teff >= 3200) return "M4";
        if (teff >= 3100) return "M5";
        if (teff >= 3000) return "M6";
    }
    return "Unknown";
}

double getBolometricCorrection(const std::string& spectralType) {
    if (spectralType[0] == 'O') {
        switch (spectralType[1]) {
            case '0': return -4.5;
            case '1': return -4.4;
            case '2': return -4.3;
            case '3': return -4.3;
            case '4': return -4.2;
            case '5': return -4.1;
            case '6': return -3.9;
            case '7': return -3.7;
            case '8': return -3.5;
            case '9': return -3.3;
        }
    } else if (spectralType[0] == 'B') {
        switch (spectralType[1]) {
            case '0': return -3.16;
            case '1': return -2.61;
            case '2': return -2.06;
            case '3': return -1.94;
            case '4': return -1.53;
            case '5': return -1.37;
            case '6': return -1.16;
            case '7': return -1.07;
            case '8': return -0.79;
            case '9': return -0.44;
        }
    } else if (spectralType[0] == 'A') {
        switch (spectralType[1]) {
            case '0': return -0.24;
            case '1': return -0.15;
            case '2': return -0.1;
            case '3': return -0.06;
            case '4': return -0.04;
            case '5': return -0.03;
            case '6': return -0.02;
            case '7': return  0.0;
            case '8': return  0.0;
            case '9': return  0.0;
        }
    } else if (spectralType[0] == 'F') {
        switch (spectralType[1]) {
            case '0': return  -0.01;
            case '1': return  -0.01;
            case '2': return  -0.02;
            case '3': return  -0.03;
            case '4': return  -0.04;
            case '5': return  -0.04;
            case '6': return  -0.05;
            case '7': return  -0.06;
            case '8': return  -0.07;
            case '9': return  -0.08;
        }
    } else if (spectralType[0] == 'G') {
        switch (spectralType[1]) {
            case '0': return  -0.09;
            case '1': return  -0.1;
            case '2': return  -0.11;
            case '3': return  -0.12;
            case '4': return  -0.13;
            case '5': return  -0.13;
            case '6': return  -0.15;
            case '7': return  -0.16;
            case '8': return  -0.17;
            case '9': return  -0.21;
        }
    } else if (spectralType[0] == 'K') {
        switch (spectralType[1]) {
            case '0': return  -0.22;
            case '1': return  -0.26;
            case '2': return  -0.29;
            case '3': return  -0.41;
            case '4': return  -0.55;
            case '5': return  -0.67;
            case '6': return  -0.86;
            case '7': return  -1.00;
            case '8': return  -1.11;
            case '9': return  -1.25;
        }
    } else if (spectralType[0] == 'M') {
        switch (spectralType[1]) {
            case '0': return  -1.3;
            case '1': return  -1.53;
            case '2': return  -1.65;
            case '3': return  -1.97;
            case '4': return  -2.59;
            case '5': return  -3.28;
            case '6': return  -4.36;
            case '7': return  -5.06;
            case '8': return  -5.66;
            case '9': return  -5.73;
        }
    }
    return 0.0;
}


int main() {
    double a0 = -0.02704;
    double a1 = 0.01424;
    double a2 = -0.2156;
    double a3 = 0.01426;
    double G = 6.673840e-11;
    double C = 44.8017709522;

    std::string inputFilePath = "C:\\Users\\(name)\\Downloads\\project_folder\\data_2d.csv"; // -> enter file path
    std::ifstream file(inputFilePath);

    if (!file.is_open()) {
        std::cerr << "Cannot open file: " << inputFilePath << std::endl;
        return 1;
    }

    std::vector<Star> stars;
    std::string line;

    std::getline(file, line);

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string value;
        Star star = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, "Unknown", 0.0};

        for (int i = 0; i < 24; ++i) {
            std::getline(ss, value, ',');

            try {
                if (i == 2) {
                    star.ra = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 3) {
                    star.dec = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 8){
                    star.G = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 9){
                    star.BP_RP = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 4) {
                    star.distance = value.empty() ? 0.0 : 1000.0 / std::stod(value);
                } else if (i == 5) {
                    star.Pra = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 6) {
                    star.Pdc = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 10){
                    star.BP_G = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 13){
                    star.Binary = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 21) {
                    if (value.empty() || value == "NOT_AVAILABLE") {
                        star.teff = 0.0;
                    } else {
                        star.teff = std::stod(value);
                    }
                } else if (i == 22) {
                    if (value.empty() || value == "NOT_AVAILABLE") {
                        star.logg = 0.0;
                    } else {
                        star.logg = std::stod(value) - 2;
                    }
                }
            } catch (const std::invalid_argument&) {
                std::cerr << "Invalid value found: " << value << " (row: " << stars.size() + 2 << ")" << std::endl;
            } catch (const std::out_of_range&) {
                std::cerr << "Value out of range: " << value << " (row: " << stars.size() + 2 << ")" << std::endl;
            }
        }

        // Determine spectral type
        star.spectralType = determineSpectralType(star.teff);

        star.BC = getBolometricCorrection(star.spectralType);

        if (star.logg < -10 || star.logg > 10 || star.teff < 1000 || star.teff > 100000) {
            std::cerr << "Abnormal value found (logg: " << star.logg << ", teff: " << star.teff << ") (row: " << stars.size() + 2 << ")" << std::endl;
            continue;
        }

        double G_V = a0 + a1 * star.BP_RP + a2 * pow(star.BP_RP, 2) + a3 * pow(star.BP_RP, 3);
        star.V = star.G - G_V;
        star.Mv = (-5 * log10(star.distance)) + 5 + star.V;
        star.Mbol = star.Mv + star.BC;
        star.logM = star.logg - (4*log10(star.teff)) - (0.4*star.Mbol) + C;
        star.logR = (star.logM - star.logg + log10(G)) / 2;
        star.R = pow(10, star.logR);
        star.M = pow(10, star.logM);


        stars.push_back(star);
    }

    file.close();

    std::ofstream outputFile("M67stellardata.txt");

    if (!outputFile.is_open()) {
        std::cerr << "Cannot open output.txt file." << std::endl;
        return 1;
    }

    #include <cmath> // std::isnan

for (const auto& star : stars) {
    if (!std::isnan(star.ra) && !std::isnan(star.dec) && !std::isnan(star.M) && 
        !std::isnan(star.R) && !std::isnan(star.distance) && !std::isnan(star.Pra) && 
        !std::isnan(star.Pdc) && !std::isnan(star.Mv) && !std::isnan(star.teff) && 
        !std::isnan(star.logg) && !std::isnan(star.Mbol) && star.distance <= 2000) {
        
        outputFile << star.ra << " " << star.dec << " " << star.M / 1.898e30 << " " << 
        star.R / 696340000 << " " << star.distance << " " << star.Pra <<  " " << 
        star.Pdc << " " << star.Mv << " " << star.teff << " " << star.logg << " " << 
        star.Mbol << "\n";
    }
}

    outputFile.close();

    std::cout << "Results have been saved to _M67stellardata.txt." << std::endl;

    return 0;
}
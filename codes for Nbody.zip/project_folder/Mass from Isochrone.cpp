#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>

struct StarData {
    double starmass;
    double n ;
    double logTeff;
    double logg;
    double logL;
    double L;
    double logM;
    double M;
    double Ms;
    double Delta;
    double Mbol;
    double B;
    double V;
    double BC_V;
    double B_V;
};

int main() {
    double a = -0.190537291496456;
    double b = 0.155144866764412;
    double c = -0.421278819301717;
    double d = 0.060458362591486;
    double Ls = 3.828*pow(10, 26);

    std::ifstream file("C:/Users/gun53/Downloads/MIST_iso_67bede5e20e8a_cleaned.csv");
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file!" << std::endl;
        return 1;
    }

    std::string line;
    std::vector<StarData> stars;
    StarData star;

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string value;
        StarData star = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};

        for (int i = 0; i < 36; ++i) {
            std::getline(ss, value, ',');

            try {
                if (i == 0) {
                    star.n = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 3) {
                    star.starmass = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 4) {
                    star.logTeff = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 5){
                    star.logg = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 6){
                    star.logL = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 10){
                    star.B = value.empty() ? 0.0 : std::stod(value);
                } else if (i == 11){
                    star.V = value.empty() ? 0.0 : std::stod(value);
                }
            } catch (const std::invalid_argument&) {
                std::cerr << "Invalid value found: " << value << " (row: " << stars.size() + 2 << ")" << std::endl;
            } catch (const std::out_of_range&) {
                std::cerr << "Value out of range: " << value << " (row: " << stars.size() + 2 << ")" << std::endl;
            }
        }
            star.Ms = 4.74;
            star.B_V = star.B - star.V;
            star.L = pow(10, star.logL + log10(Ls));
            star.BC_V = a * star.B_V + b * pow(star.B_V, 2) + c * pow(star.B_V, 3) + d * pow(star.B_V, 4);
            star.Mbol = (-2.5 * log10(star.L))+ 2.5*(log10(3.0128)+28);
            star.logM = star.logg -2 - 4 * star.logTeff - 0.4 * (star.Mbol) + 44.8017709522;
            star.M = pow(10, star.logM)/(1.988 * pow(10, 30));
            star.Delta = star.starmass - star.M;

            stars.push_back(star);
    }
    file.close();

    // 결과 출력
    for (const auto& star : stars) {
        std::cout << "No.: " << star.n << ", Mass: " << star.starmass << ", logTeff: " << star.logTeff
                  << ", logg: " << star.logg << ", logL: " << star.logL << ", L: " << star.L << ", Mbol: " << star.Mbol << ", M: " << star.M
                  << ", Delta: " << star.Delta << std::endl;
    }
    double deltaSum = 0.0;
    for (const auto& star : stars) {
        deltaSum += star.Delta;
    }
    double deltaAvg = stars.empty() ? 0.0 : deltaSum / stars.size();
    
    std::cout << "Average Delta: " << deltaAvg << std::endl;
    
    return 0;
}

#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ofstream file("output.txt");

    if (file.is_open()) {
        const double RA_OFFSET = 265.0833;
        const double DEC_OFFSET = 32.2167;
        int N = 484;


        for (int i = 1; i <= N; ++i) {
            file << "double x" << i << " = (ra" << i << " - " << RA_OFFSET << ") * distance" << i << ";\n";
            file << "double y" << i << " = (dec" << i << " + " << DEC_OFFSET << ") * distance" << i << ";\n";
            file << "double z" << i << " = distance" << i << ";\n\n";
            file << "bodies.push_back(Body(Vector(x" << i << ", y" << i << ", z" << i 
                 << "), Vector(0, 0, 0), mass" << i << ", radius" << i << "));\n\n";
        }
        file.close();
        cout << "File output.txt created successfully!" << endl;
    } else {
        cerr << "Error: Unable to open file!" << endl;
    }

    return 0;
}

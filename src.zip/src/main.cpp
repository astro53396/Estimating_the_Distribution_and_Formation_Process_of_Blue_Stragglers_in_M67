#include "ofApp.h"
#include "ofMain.h"

int main() {
  ofSetupOpenGL(3840, 2160, OF_WINDOW);
  ofRunApp(new ofApp());
}
